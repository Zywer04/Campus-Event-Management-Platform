//代码模拟了“发布活动”的完整流程，但并没有真正将数据保存到后端服务器
//需要修改一下逻辑，代码在
// const drafts = JSON.parse(localStorage.getItem("activityDrafts") || "[]");
// const newDraft = {
//   id: Date.now(),
//   ...formData,
//   savedAt: new Date().toISOString(),
// };
// drafts.push(newDraft);
// localStorage.setItem("activityDrafts", JSON.stringify(drafts));


//这部分把数据保存到浏览器本地了，需要传到后端，然后同步到首页里面，这部分都是前后端数据交互部分
import React, { useState } from "react";
const App: React.FC = () => {
  const [formData, setFormData] = useState({
    title: "",
    coverImage: null,
    type: "",
    startTime: "",
    endTime: "",
    location: "",
    details: "",
    maxParticipants: "",
    registrationDeadline: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [previewImage, setPreviewImage] = useState<string>("");
  const activityTypes = [
    { id: "academic", name: "学术讲座" },
    { id: "sports", name: "文体活动" },
    { id: "culture", name: "文化艺术" },
    { id: "career", name: "职业发展" },
    { id: "other", name: "其他" },
  ];
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.title.trim()) {
      newErrors.title = "请输入活动标题";
    }
    if (!formData.coverImage) {
      newErrors.coverImage = "请上传活动封面";
    }
    if (!formData.type) {
      newErrors.type = "请选择活动类型";
    }
    if (!formData.startTime) {
      newErrors.startTime = "请选择开始时间";
    }
    if (!formData.endTime) {
      newErrors.endTime = "请选择结束时间";
    }
    if (!formData.location.trim()) {
      newErrors.location = "请输入活动地点";
    }
    if (!formData.details.trim()) {
      newErrors.details = "请输入活动详情";
    }
    if (!formData.maxParticipants) {
      newErrors.maxParticipants = "请输入人数上限";
    }
    if (!formData.registrationDeadline) {
      newErrors.registrationDeadline = "请选择报名截止时间";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const validateImage = (file: File): boolean => {
    const maxSize = 5 * 1024 * 1024; // 5MB
    const allowedTypes = ["image/jpeg", "image/png", "image/gif"];
    const minWidth = 800;
    const minHeight = 600;
    if (!allowedTypes.includes(file.type)) {
      alert("请上传 PNG, JPG 或 GIF 格式的图片");
      return false;
    }
    if (file.size > maxSize) {
      alert("图片大小不能超过 5MB");
      return false;
    }
    return new Promise<boolean>((resolve) => {
      const img = new Image();
      img.onload = () => {
        if (img.width < minWidth || img.height < minHeight) {
          alert(`图片尺寸至少需要 ${minWidth}x${minHeight} 像素`);
          resolve(false);
        }
        resolve(true);
      };
      img.src = URL.createObjectURL(file);
    });
  };
  const [showImageEditor, setShowImageEditor] = useState(false);
  const [imageEditorData, setImageEditorData] = useState({
    brightness: 100,
    contrast: 100,
    scale: 1,
    position: { x: 0, y: 0 },
  });
  const [originalImage, setOriginalImage] = useState<string>("");

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && validateImage(file)) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setOriginalImage(reader.result as string);
        setShowImageEditor(true);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleImageAdjustments = () => {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    const img = new Image();

    img.onload = () => {
      canvas.width = 800;
      canvas.height = 600;

      if (ctx) {
        ctx.filter = `brightness(${imageEditorData.brightness}%) contrast(${imageEditorData.contrast}%)`;
        const scale = imageEditorData.scale;
        const sx = -imageEditorData.position.x / scale;
        const sy = -imageEditorData.position.y / scale;
        const sWidth = canvas.width / scale;
        const sHeight = canvas.height / scale;

        ctx.drawImage(
          img,
          sx,
          sy,
          sWidth,
          sHeight,
          0,
          0,
          canvas.width,
          canvas.height,
        );

        canvas.toBlob((blob) => {
          if (blob) {
            const file = new File([blob], "cropped_image.jpg", {
              type: "image/jpeg",
            });
            setFormData({ ...formData, coverImage: file });
            setPreviewImage(canvas.toDataURL("image/jpeg"));
          }
          setShowImageEditor(false);
        }, "image/jpeg");
      }
    };

    img.src = originalImage;
  };
  const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    const file = event.dataTransfer.files?.[0];
    if (file && validateImage(file)) {
      setFormData({ ...formData, coverImage: file });
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  const handleDragOver = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
  };
  const removeImage = () => {
    setFormData({ ...formData, coverImage: null });
    setPreviewImage("");
    const fileInput = document.getElementById(
      "file-upload",
    ) as HTMLInputElement;
    if (fileInput) {
      fileInput.value = "";
    }
  };
  const [showToast, setShowToast] = useState(false);
  const [toastConfig, setToastConfig] = useState({
    message: "",
    type: "success",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPublishFeedback, setShowPublishFeedback] = useState(false);
  const [publishResult, setPublishResult] = useState<{
    success: boolean;
    activityId?: string;
    error?: string;
  }>({ success: false });
  const handleSubmit = async (isDraft: boolean) => {
    if (!isDraft && !validateForm()) {
      return;
    }
    if (isDraft) {
      const drafts = JSON.parse(localStorage.getItem("activityDrafts") || "[]");
      const newDraft = {
        id: Date.now(),
        ...formData,
        savedAt: new Date().toISOString(),
      };
      drafts.push(newDraft);
      localStorage.setItem("activityDrafts", JSON.stringify(drafts));
      setToastConfig({
        message: "活动草稿已保存成功",
        type: "success",
      });
      setShowToast(true);
      setTimeout(() => {
        setShowToast(false);
      }, 3000);
    } else {
      setIsSubmitting(true);
      try {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1500));
        // Mock successful response
        const response = {
          success: true,
          activityId: Date.now().toString(),
        };
        setPublishResult({
          success: true,
          activityId: response.activityId,
        });
      } catch (error) {
        setPublishResult({
          success: false,
          error: "发布失败，请稍后重试",
        });
      } finally {
        setIsSubmitting(false);
        setShowPublishFeedback(true);
      }
    }
  };
  const handleClosePublishFeedback = () => {
    setShowPublishFeedback(false);
    if (publishResult.success) {
      window.location.href = "/activities";
    }
  };
  return (
    <div className="min-h-screen bg-gray-50">
      {/* 顶部导航 */}
      <nav className="fixed top-0 left-0 right-0 h-16 bg-white shadow-sm z-50">
        <div className="max-w-[1440px] mx-auto px-6 h-full flex items-center">
          <a
            href="https://readdy.ai/home/b0cf731b-de36-44f8-8c9f-e57d09ede402/446a40e3-0c00-4354-93ed-34b1ad9576e3"
            data-readdy="true"
            className="flex items-center text-gray-600 hover:text-purple-600"
          >
            <i className="fas fa-arrow-left mr-3"></i>
            <span>返回</span>
          </a>
          <h1 className="text-lg font-semibold ml-6">发布活动</h1>
        </div>
      </nav>
      {/* 主内容区 */}
      <main className="pt-24 pb-32 px-6">
        <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-sm p-8">
          <form className="space-y-8">
            {/* 活动标题 */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                活动标题 <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) =>
                  setFormData({ ...formData, title: e.target.value })
                }
                className="w-full px-4 py-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="请输入活动标题"
              />
              {errors.title && (
                <p className="mt-1 text-sm text-red-500">{errors.title}</p>
              )}
            </div>
            {/* 活动封面 */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                活动封面 <span className="text-red-500">*</span>
              </label>
              <div className="mt-2">
                <div
                  className="flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer hover:border-purple-500"
                  onDrop={handleDrop}
                  onDragOver={handleDragOver}
                >
                  <div className="space-y-1 text-center">
                    {previewImage ? (
                      <div className="relative">
                        <img
                          src={previewImage}
                          alt="预览"
                          className="mx-auto h-32 w-auto"
                        />
                        <button
                          type="button"
                          onClick={removeImage}
                          className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center hover:bg-red-600 transition-colors"
                        >
                          <i className="fas fa-times text-xs"></i>
                        </button>
                      </div>
                    ) : (
                      <i className="fas fa-cloud-upload-alt text-gray-400 text-3xl mb-3"></i>
                    )}
                    <div className="flex text-sm text-gray-600 justify-center">
                      <label
                        htmlFor="file-upload"
                        className="relative cursor-pointer bg-white rounded-md font-medium text-purple-600 hover:text-purple-500"
                      >
                        <span>上传图片</span>
                        <input
                          id="file-upload"
                          name="file-upload"
                          type="file"
                          className="sr-only"
                          accept="image/*"
                          onChange={handleImageUpload}
                        />
                      </label>
                      <p className="pl-1">或拖放图片到此处</p>
                    </div>
                    <p className="text-xs text-gray-500">
                      支持 PNG, JPG, GIF 格式
                    </p>
                    <p className="text-xs text-gray-500">
                      建议尺寸至少 800x600 像素，大小不超过 5MB
                    </p>
                  </div>
                </div>
              </div>
              {errors.coverImage && (
                <p className="mt-1 text-sm text-red-500">{errors.coverImage}</p>
              )}
            </div>
            {/* 活动类型 */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                活动类型 <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <select
                  value={formData.type}
                  onChange={(e) =>
                    setFormData({ ...formData, type: e.target.value })
                  }
                  className="w-full px-4 py-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent appearance-none"
                >
                  <option value="">请选择活动类型</option>
                  {activityTypes.map((type) => (
                    <option key={type.id} value={type.id}>
                      {type.name}
                    </option>
                  ))}
                </select>
                <i className="fas fa-chevron-down absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"></i>
              </div>
              {errors.type && (
                <p className="mt-1 text-sm text-red-500">{errors.type}</p>
              )}
            </div>
            {/* 活动时间 */}
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  开始时间 <span className="text-red-500">*</span>
                </label>
                <input
                  type="datetime-local"
                  value={formData.startTime}
                  onChange={(e) =>
                    setFormData({ ...formData, startTime: e.target.value })
                  }
                  className="w-full px-4 py-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
                {errors.startTime && (
                  <p className="mt-1 text-sm text-red-500">
                    {errors.startTime}
                  </p>
                )}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  结束时间 <span className="text-red-500">*</span>
                </label>
                <input
                  type="datetime-local"
                  value={formData.endTime}
                  onChange={(e) =>
                    setFormData({ ...formData, endTime: e.target.value })
                  }
                  className="w-full px-4 py-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
                {errors.endTime && (
                  <p className="mt-1 text-sm text-red-500">{errors.endTime}</p>
                )}
              </div>
            </div>
            {/* 活动地点 */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                活动地点 <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.location}
                onChange={(e) =>
                  setFormData({ ...formData, location: e.target.value })
                }
                className="w-full px-4 py-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="请输入活动地点"
              />
              {errors.location && (
                <p className="mt-1 text-sm text-red-500">{errors.location}</p>
              )}
            </div>
            {/* 活动详情 */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                活动详情 <span className="text-red-500">*</span>
              </label>
              <textarea
                value={formData.details}
                onChange={(e) =>
                  setFormData({ ...formData, details: e.target.value })
                }
                rows={6}
                className="w-full px-4 py-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="请输入活动详情描述"
              ></textarea>
              {errors.details && (
                <p className="mt-1 text-sm text-red-500">{errors.details}</p>
              )}
            </div>
            {/* 报名人数上限 */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                报名人数上限 <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                min="1"
                value={formData.maxParticipants}
                onChange={(e) =>
                  setFormData({ ...formData, maxParticipants: e.target.value })
                }
                className="w-full px-4 py-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="请输入人数上限"
              />
              {errors.maxParticipants && (
                <p className="mt-1 text-sm text-red-500">
                  {errors.maxParticipants}
                </p>
              )}
            </div>
            {/* 报名截止时间 */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                报名截止时间 <span className="text-red-500">*</span>
              </label>
              <input
                type="datetime-local"
                value={formData.registrationDeadline}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    registrationDeadline: e.target.value,
                  })
                }
                className="w-full px-4 py-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
              {errors.registrationDeadline && (
                <p className="mt-1 text-sm text-red-500">
                  {errors.registrationDeadline}
                </p>
              )}
            </div>
          </form>
        </div>
      </main>
      {/* Toast Notification */}
      <div
        className={`fixed top-4 right-4 ${toastConfig.type === "success" ? "bg-green-500" : "bg-red-500"} text-white px-6 py-3 rounded-lg shadow-lg transform transition-transform duration-300 z-50 ${
          showToast
            ? "translate-y-0 opacity-100"
            : "-translate-y-full opacity-0"
        }`}
      >
        <div className="flex items-center">
          <i
            className={`fas ${toastConfig.type === "success" ? "fa-check-circle" : "fa-exclamation-circle"} mr-2`}
          ></i>
          <span>{toastConfig.message}</span>
        </div>
      </div>
      {/* Image Editor Modal */}
      {showImageEditor && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 max-w-4xl w-full mx-4">
            <div className="space-y-6">
              <h3 className="text-xl font-semibold">编辑图片</h3>
              <div className="relative w-full h-[400px] bg-gray-100 overflow-hidden rounded-lg">
                <img
                  src={originalImage}
                  alt="编辑预览"
                  className="absolute transform-gpu transition-transform"
                  style={{
                    transform: `scale(${imageEditorData.scale}) translate(${imageEditorData.position.x}px, ${imageEditorData.position.y}px)`,
                    filter: `brightness(${imageEditorData.brightness}%) contrast(${imageEditorData.contrast}%)`,
                  }}
                />
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    亮度
                  </label>
                  <input
                    type="range"
                    min="50"
                    max="150"
                    value={imageEditorData.brightness}
                    onChange={(e) =>
                      setImageEditorData({
                        ...imageEditorData,
                        brightness: Number(e.target.value),
                      })
                    }
                    className="w-full"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    对比度
                  </label>
                  <input
                    type="range"
                    min="50"
                    max="150"
                    value={imageEditorData.contrast}
                    onChange={(e) =>
                      setImageEditorData({
                        ...imageEditorData,
                        contrast: Number(e.target.value),
                      })
                    }
                    className="w-full"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    缩放
                  </label>
                  <input
                    type="range"
                    min="100"
                    max="200"
                    value={imageEditorData.scale * 100}
                    onChange={(e) =>
                      setImageEditorData({
                        ...imageEditorData,
                        scale: Number(e.target.value) / 100,
                      })
                    }
                    className="w-full"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-4 mt-6">
                <button
                  onClick={() => setShowImageEditor(false)}
                  className="px-6 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors whitespace-nowrap !rounded-button"
                >
                  取消
                </button>
                <button
                  onClick={handleImageAdjustments}
                  className="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors whitespace-nowrap !rounded-button"
                >
                  应用
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      {/* Publish Feedback Modal */}
      {showPublishFeedback && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 max-w-md w-full mx-4">
            <div className="text-center">
              {publishResult.success ? (
                <>
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className="fas fa-check text-2xl text-green-500"></i>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">发布成功</h3>
                  <p className="text-gray-600 mb-6">您的活动已成功发布</p>
                  <div className="flex justify-center gap-4">
                    <a
                      href={`/activity/${publishResult.activityId}`}
                      className="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors whitespace-nowrap !rounded-button"
                    >
                      查看活动
                    </a>
                    <button
                      onClick={handleClosePublishFeedback}
                      className="px-6 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors whitespace-nowrap !rounded-button"
                    >
                      返回列表
                    </button>
                  </div>
                </>
              ) : (
                <>
                  <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className="fas fa-times text-2xl text-red-500"></i>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">发布失败</h3>
                  <p className="text-gray-600 mb-6">{publishResult.error}</p>
                  <button
                    onClick={() => setShowPublishFeedback(false)}
                    className="px-6 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors whitespace-nowrap !rounded-button"
                  >
                    关闭
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      )}
      {/* 底部操作栏 */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200">
        <div className="max-w-3xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <button
              id="save-draft-btn"
              onClick={() => handleSubmit(true)}
              className="px-6 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors cursor-pointer whitespace-nowrap !rounded-button"
            >
              保存草稿
            </button>
            <a
              href="/drafts"
              className="text-gray-600 hover:text-purple-600 text-sm flex items-center"
            >
              <i className="fas fa-file-alt mr-1"></i>
              草稿箱
            </a>
          </div>
          <button
            id="publish-activity-btn"
            onClick={() => handleSubmit(false)}
            disabled={isSubmitting}
            className={`px-6 py-2 bg-purple-600 text-white rounded-lg transition-colors cursor-pointer whitespace-nowrap !rounded-button flex items-center justify-center min-w-[120px] ${
              isSubmitting
                ? "opacity-75 cursor-not-allowed"
                : "hover:bg-purple-700"
            }`}
          >
            {isSubmitting ? (
              <>
                <i className="fas fa-spinner fa-spin mr-2"></i>
                发布中...
              </>
            ) : (
              "发布活动"
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
export default App;
